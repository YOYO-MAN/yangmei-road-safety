# 楊光梅好、安全第一

桃園市立楊梅高級中等學校｜高二交通安全充實課程

教師講授與個人練習版

以校內課程模組、教案及簡報為主要來源。教師統一講解與提問，學生完成個人情境練習及檢核。完整來源對照見 materials/source-notes.md。

本資料夾為靜態網站，可在 GitHub Pages 使用。影片使用原發布者連結及原播放器，未重新上傳第三方內容。

[開啟教師講授與個人練習版](https://yoyo-man.github.io/yangmei-road-safety/teacher-led/)
